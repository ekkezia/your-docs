VERSION_TUPLE = (0, 8, 2)
__version__ = ".".join(map(str, VERSION_TUPLE))
